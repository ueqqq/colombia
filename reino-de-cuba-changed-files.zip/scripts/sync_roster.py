#!/usr/bin/env python3
"""
Pulls this nation's towns + residents from the DiplomaticaMC live map and
writes roster.json — a same-origin snapshot the website reads as a fallback
when it can't fetch the map directly (CORS).

Mirrors roster-core.js's parsing logic (same markers.json schema, same
mayor-first resident ordering). If the map's data shape ever changes,
update both files together.

Usage:
    python3 scripts/sync_roster.py                     # fetches the live map
    python3 scripts/sync_roster.py --file markers.json  # parses a local copy instead

CONFIRMED SCHEMA (verified against a real markers.json pull from
map.diplomaticamc.com):

    GET {MAP_BASE}/tiles/{MAP_WORLD}/markers.json
    -> { "layers": [ { "id": "towny_claims", "markers": [ ... ] }, ... ] }

Each marker in the "towny_claims" layer has a "meta" dict with keys like
"%town%", "%nation%", "%mayor%", "%residents%" (comma-separated, mayor not
guaranteed to be listed first).
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

MAP_BASE = "https://map.diplomaticamc.com"
MAP_WORLD = "minecraft_overworld"
NATION_FILTER = "Cuba"
OUTPUT_PATH = Path(__file__).resolve().parent.parent / "roster.json"
BUNDLE_PATH = Path(__file__).resolve().parent.parent / "js" / "roster-data.js"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)


def fetch_markers_json(url: str) -> dict:
    """Fetch markers.json from the live map."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        if resp.status != 200:
            raise RuntimeError(f"markers.json responded with HTTP {resp.status}")
        return json.loads(resp.read().decode("utf-8"))


def load_markers_json(path: Path) -> dict:
    """Load markers.json from a local file instead of fetching it."""
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def parse_town(marker: dict) -> dict:
    """Turn one towny_claims marker into {name, nation, mayor, residents}."""
    meta = marker.get("meta", {})
    if not isinstance(meta, dict):
        return {"name": "", "nation": "", "mayor": None, "residents": []}

    name = str(meta.get("%town%", "") or "").replace("_", " ").strip()
    nation = str(meta.get("%nation%", "") or "").strip()
    mayor_value = meta.get("%mayor%", "")
    mayor = str(mayor_value or "").strip() or None

    resident_value = meta.get("%residents%", "")
    residents = [
        resident.strip()
        for resident in str(resident_value or "").split(",")
        if resident.strip()
    ]

    # Keep one spelling of each username and place the map's explicit mayor
    # first without assuming that the first listed resident is the mayor.
    unique = {}
    for resident in residents:
        unique.setdefault(resident.casefold(), resident)
    if mayor:
        unique = {key: value for key, value in unique.items() if key != mayor.casefold()}
        residents = [mayor, *unique.values()]
    else:
        residents = list(unique.values())

    return {
        "name": name,
        "nation": nation,
        "mayor": mayor,
        "residents": [{"username": r} for r in residents],
    }


def find_nation_towns(markers_data: dict, nation: str) -> list[dict]:
    """Filter and sort every town belonging to `nation`."""
    if not isinstance(markers_data, dict):
        raise RuntimeError("markers.json root must be an object.")
    layers = markers_data.get("layers", [])
    if not isinstance(layers, list):
        raise RuntimeError('markers.json "layers" must be a list.')
    claims_layer = next((
        layer for layer in layers
        if isinstance(layer, dict) and layer.get("id") == "towny_claims"
    ), None)
    if claims_layer is None:
        raise RuntimeError('No "towny_claims" layer in markers.json — has the map plugin changed?')

    markers = claims_layer.get("markers", [])
    if not isinstance(markers, list):
        raise RuntimeError('"towny_claims" markers are not a list.')

    towns_by_name = {}
    for marker in markers:
        if not isinstance(marker, dict):
            continue
        town = parse_town(marker)
        if not town["name"] or town["nation"] != nation or not town["residents"]:
            continue
        key = town["name"].casefold()
        existing = towns_by_name.get(key)
        if existing is None:
            towns_by_name[key] = town
            continue
        known_residents = {r["username"].casefold() for r in existing["residents"]}
        for resident in town["residents"]:
            if resident["username"].casefold() not in known_residents:
                existing["residents"].append(resident)
                known_residents.add(resident["username"].casefold())
        if not existing["mayor"] and town["mayor"]:
            existing["mayor"] = town["mayor"]

    towns = sorted(towns_by_name.values(), key=lambda t: t["name"].casefold())

    if not towns:
        raise RuntimeError(f'No towns matched nation "{nation}".')
    return towns


def build_roster(towns: list[dict], nation: str) -> dict:
    towns_out = [
        {"name": t["name"], "mayor": t["mayor"], "residents": t["residents"]}
        for t in towns
    ]
    # Counts are derived from the exact arrays written to the file, so the
    # headline numbers can never disagree with what the site renders.
    resident_count = sum(len(t["residents"]) for t in towns_out)
    return {
        "updatedAt": datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
        "nation": nation,
        "townCount": len(towns_out),
        "residentCount": resident_count,
        "towns": towns_out,
        "schemaVersion": 3,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--file", type=Path, help="Parse a local markers.json instead of fetching live")
    parser.add_argument("--nation", default=NATION_FILTER, help=f"Nation to filter by (default: {NATION_FILTER})")
    parser.add_argument("--output", type=Path, default=OUTPUT_PATH, help=f"Output path (default: {OUTPUT_PATH})")
    args = parser.parse_args()

    markers_data = load_markers_json(args.file) if args.file else fetch_markers_json(
        f"{MAP_BASE}/tiles/{MAP_WORLD}/markers.json"
    )

    towns = find_nation_towns(markers_data, args.nation)
    roster = build_roster(towns, args.nation)

    roster_json = json.dumps(roster, indent=2)
    args.output.write_text(roster_json + "\n", encoding="utf-8")
    BUNDLE_PATH.write_text(
        "// Generated by scripts/sync_roster.py; do not edit by hand.\n"
        "window.CUBA_ROSTER_DATA = " + roster_json + ";\n",
        encoding="utf-8",
    )
    print(f"Wrote {roster['townCount']} towns ({roster['residentCount']} residents) to {args.output}")
    print(f"Wrote browser-compatible roster bundle to {BUNDLE_PATH}")


if __name__ == "__main__":
    try:
        main()
    except Exception as err:  # noqa: BLE001
        print(f"Roster sync failed: {err}", file=sys.stderr)
        sys.exit(1)
